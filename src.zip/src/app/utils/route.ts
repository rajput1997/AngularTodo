export const EndRoute= {
    "CUSTOMER":"data"
}
